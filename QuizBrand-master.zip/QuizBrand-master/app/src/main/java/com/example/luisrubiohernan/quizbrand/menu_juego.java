package com.example.luisrubiohernan.quizbrand;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class menu_juego extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_juego);
    }

    public void onClickJuegoNombresActivity(View v){
        Intent view =new Intent(getApplicationContext(),JuegoNombresActivity.class);
        startActivity(view);
    }

    public void onClickJuegoPaisesActivity(View view) {
        Intent intent = new Intent(this, JuegoPaisesActivity.class);
        startActivityForResult(intent, 0);
    }

    public void onClickJuegoSectoresActivity(View view) {
        Intent intent = new Intent(this, JuegoSectoresActivity.class);
        startActivityForResult(intent, 0);
    }

    public void onClickHighScoresActivity(View v){
        Intent view =new Intent(getApplicationContext(),HighScoresActivity.class);
        startActivity(view);
    }
}
