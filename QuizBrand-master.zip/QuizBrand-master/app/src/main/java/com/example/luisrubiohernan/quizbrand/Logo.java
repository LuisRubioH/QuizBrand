package com.example.luisrubiohernan.quizbrand;

public class Logo {
    private String Name, Country, Sector, ImagePath;
    
    public String getName() {
        return Name;
    }

    public String getCountry() {
        return Country;
    }

    public String getSector() {
        return Sector;
    }

    public String getImagePath() {
        return ImagePath;
    }
}
